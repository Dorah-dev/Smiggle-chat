
//##########################################################################
//##### Creating our controller by calling our angular module variable.#####
//##### Controller Receives 2 parameters which are controller name and #####
//##### function that receives 2 parameters of $scope and the FactoryNAme ##
//#########################################################################
Smiggle chatApp.controller("registerController", function($scope,registerFactory,loginFactory){

//Creating a function using a scope variable
//Which is basically a view button
 $scope.registerUser = function()
		{
			//############################
			//### Variables from View 
			//##    from ng-model ##
			//############################
			var userDetails = {firstname : $scope.firstname, 
							lastname : $scope.lastname,
							email : $scope.email,
							password : $scope.password};
			
			registerFactory.signup(userDetails)
			.then(function(response){
					console.log("successfully add");
					$scope.firstname = "";
					$scope.lastname ="";
					$scope.email = "";
					$scope.password = "";
				});
		};
});