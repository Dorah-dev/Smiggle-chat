<?php
include("connect_php/connect.php");

$firstname = $_GET["txtfirstname"];
$lastname = $_GET["txtlastname"];
$email = $_GET["txtemail"];
$Password = $_GET["txtpassword"];
$points = "";
$address = "";
$idnumber = "";
$cell = "";
$id = "";
$resultArray = array();

$action = $_GET['input'];
switch($action){
	case 'register':

	$results = $db_connection->prepare("CALL prc_reg_users(?,?,?,?)");

	if(!$results){
		die("Prepare error " . mysqli_error());
		}

	$results->bind_param("ssss",$firstname,$lastname,$email,$Password);

	if(!$results->execute()){
	die("Could not execute");
	}
	$results->bind_result($id,$firstname,$lastname,$email,$Password,$points,$address,$idnumber,$cell);
	while ($results->fetch()) {
                 array_push($resultArray,
                            array(
                    'userID'            => $id,
                    'firstname'        =>  $firstname,
                    'lastname'            =>  $lastname,
                    'email'            =>  $email,
                    'password'        =>  $Password,       
                    
                            
                  )
                );
               
            }

break ;
mysqli_close($db_connection);
}
echo json_encode($resultArray);
			







		
			
?>