var App = angular.module("myapp", []);
App.controller("InsController" , function($scope,$http){

	  $scope.InsertData = function(){
      $http.post("../php/register.php",{'firstname':$scope.Fname,'lastname':$scope.Lname,'Email':$scope.Email,'Pword':$scope.Pword})
      .success(function(data,status,headers,config){
      	console.log("data inserted");


      });
   }
});
   

